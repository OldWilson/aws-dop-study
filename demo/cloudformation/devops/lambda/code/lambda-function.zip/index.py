def handler(event, context):
    # Print out the bucket list
    print("hello world")

    return "success"